# Swiggy-Clone
![image](https://github.com/user-attachments/assets/3cedfe94-6b8e-4964-9a16-0ae2cd16eb23)
